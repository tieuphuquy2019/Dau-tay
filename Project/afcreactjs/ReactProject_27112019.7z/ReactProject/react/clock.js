import React, { Component } from "react";

var a = 1000;

class clock1 extends React.Component{

  constructor(props) {
    super(props);
    this.timer = this.timer.bind(this)
    this.state = {
      currentCount : 1000
    };
  }

  getInitialState() {
   // return { currentCount: 10 };
  };

  componentDidMount() {
    this.countdown = setInterval(this.timer, 1000);
  };

  componentWillUnmount() {
   // clearInterval(this.countdown);
  };

  timer() {
    a = a -1 ;
    this.setState({ currentCount: a });
  };

 
  render () {
    var displayCount = this.state.currentCount--;
    return (
      <div>
      
        {displayCount}
      
      </div>
    )
  };

}

export default clock1;