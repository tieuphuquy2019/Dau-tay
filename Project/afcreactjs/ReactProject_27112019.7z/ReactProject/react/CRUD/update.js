import React from 'react';
import axios from 'axios';

import API from './API';
//axios.create({
//    baseURL: `http://localhost:1508`
//  });

export default class DelData extends React.Component {
  state = {
    Id: null, 
    Name: '',
    Location: '',
  }

  handleChangeName = event => {
    this.setState({ Name: event.target.value});
  }

  handleChangeLocation = event => {
    this.setState({ Location: event.target.value});
  }

   handleChangeId = event => {
    this.setState({ Id: event.target.value});
  }

  handleChangeUpdate = event => {
    event.preventDefault();

    const Employees = {
        Id: this.state.Id,
        Name: this.state.Name,
        Location: this.state.Location,
    };

    API.put('api/Employees')
      .then(res => {
        console.log(res);
        console.log(res.data);
      });
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleChangeUpdate}>
          <label>
            Id:
            <input type="text" name="Id" onChange={this.handleChangeUpdate} />
          </label>
          <br></br>
         
          <br></br>
          <button type="Update">Update</button>
        </form>
      </div>
    )
  }
}

