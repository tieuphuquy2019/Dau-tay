import React from 'react';
import axios from 'axios';
import API from './API';
export default class PostData extends React.Component {
  state = {
    Name: '',
    Location: '',
  }

  handleChangeName = event => {
    this.setState({ Name: event.target.value});
  }

  handleChangeLocation = event => {
    this.setState({ Location: event.target.value});
  }

  handleSubmit = event => {
    
    event.preventDefault();

    const Employees = {
        Name: this.state.Name,
        Location: this.state.Location,
    };

    API.post('send-email', { Employees })
      .then(res => {
        console.log(res);
        console.log(res.data);
      })
      
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <label>
            Person Name:
            <input type="text" name="Name" onChange={this.handleChangeName} />
          </label>
          <br></br>
          <label>
            Location:
            <input type="text" name="Location" onChange={this.handleChangeLocation} />
          </label>
          <br></br>
          <button type="submit">Add</button>
        </form>
      </div>
    )
  }
}

