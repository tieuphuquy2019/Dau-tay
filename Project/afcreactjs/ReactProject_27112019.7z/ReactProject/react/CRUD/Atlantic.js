
import React from 'react';
import ReactDOM from 'react-dom';

const Atlantic = () => {
    return ( <div>
        <h3>Atlantic Ocean</h3>
        <p>
        The Atlantic Ocean covers approximately 1/5th of the
        surface of the earth.
        </p>
    </div>
    )
};

export default Atlantic;