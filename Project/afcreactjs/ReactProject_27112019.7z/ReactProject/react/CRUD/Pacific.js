import React from 'react';
import ReactDOM from 'react-dom';

const Pacific = () => {
      return (
            <div>
                <h3>Pacific Ocean</h3>
                <p>
                Ferdinand Magellan, a Portuguese explorer, named the ocean
                'mar pacifico' in 1521, which means peaceful sea.
                </p>
            </div>
      ) 
};

export default Pacific;