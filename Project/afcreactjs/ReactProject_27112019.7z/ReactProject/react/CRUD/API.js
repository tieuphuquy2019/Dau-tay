import axios from "axios";

export default axios.create({
  baseURL: "http://localhost:1514/",
  responseType: "json"
});