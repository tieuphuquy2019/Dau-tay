import React from 'react';
import ReactDOM from 'react-dom';
//import Atlantic from './Atlantic'
//import Pacific from './Pacific'
//import Route from './Route'
//import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Contacts from './contacts';
import axios from 'axios';
import API from './API';
import socketIOClient from "socket.io-client";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect,
  Switch,
  NavLink
  } from 'react-router-dom'


var a = 1000;
var b = 1000;

class GetData extends React.Component {

  constructor(props) {
    super(props);
    this.timer = this.timer.bind(this)
    this.getAPIemPloyees = this.getAPIemPloyees.bind(this)
    this.state = {
      currentCount : 1000,
      endpoint: "http://localhost:1514",
      Employ: [],
      response: 1000,
    };
  }



  componentDidMount() {

     
    
    const socket = socketIOClient(this.state.endpoint);
    socket.on('findfinish', (b) => {
      this.setState({ response: b.num });  
         if (b.num % 2 === 0){
           document.body.style.backgroundColor = 'red';
       }
       else
       {
         document.body.style.backgroundColor = 'blue';
       }
        
      
    });
    this.countdown = setInterval(this.timer, 10000);
    //this.getAPIemPloyees(); 
    
 
 

   
  };
  
  componentWillUnmount() {
   
}

getAPIemPloyees()
{
  this.state.endpoint = 'http://localhost:1514/api/Employees1';
  const socket = socketIOClient(this.state.endpoint);
  socket.on('getAPIemPloyees', (data) => {
            API.get('api/Employees2').then(res => {
            const Employ = res.data;
            this.setState({ Employ });
        }) 
    })
};

  timer =() =>{
    const socket = socketIOClient(this.state.endpoint);
    a = a -1 ;
    socket.emit("khaitest",a);
   // const socket = socketIOClient(this.state.endpoint);
   //  socket.emit('change color', this.state.color) // change 'red' to this.state.color
   //  socket.on('change color', (col) => {
   //    document.body.style.backgroundColor = 'blue';
       
  };

 
  render () {
    var displayCount = this.state.currentCount--;
    return (
      <div>
        {this.state.response}
        
         <div><Contacts contacts={this.state.Employ} /></div>
      </div>
    )
  };
};



export default GetData;
