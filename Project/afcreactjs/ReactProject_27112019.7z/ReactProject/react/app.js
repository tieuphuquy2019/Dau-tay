import React from 'react';
import ReactDOM from 'react-dom';
//import Atlantic from './CRUD/Atlantic'
//import Pacific from './CRUD/Pacific'
//import Route from './Route'

import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import axios from 'axios';
import GetData from './CRUD/get';
import PostData from './CRUD/post';
import DelData from './CRUD/detete';
import UpData from './CRUD/update';

class App extends React.Component {
   
    render() {
        return (
            <div>
                <div>
                 <GetData />
                 </div>
                 <hr></hr>
                 <div>
                 <PostData />
                 </div> 
                <hr></hr>
                <div>
                      <DelData />
                 </div> 
                 <div>
                      <UpData />
                 </div>
            </div>
             
          )
      }
};




export default App;
