import React from 'react';
//import 'bootstrap/dist/css/bootstrap'; 
//import { Button } from 'reactstrap';
import ReactDOM from 'react-dom';

//import '/bootstrap/dist/css/bootstrap.css';
//import 'bootstrap/dist/css/bootstrap.min.css';

class Product extends React.Component {
    constructor(props, context) {
        super(props)
        this.handleUpVote = this.handleUpVote.bind(this);
        this.props = {
            //title: 'Yellow Pail1',
        }

        this.state = {
          //  "id": 1,
          //  "title": "Yellow Pail",
          //  "description": "On-demand sand castle construction expertise.",
          //  "url": "#",
          //  "votes": 41,
          //  "submitterAvatarURL": "react/assets/images/daniel.jpg",
          //  "productImageUrl": "react/assets/images/image-aqua.png"

        }
    }
    componentDidMount() {
        this.setState();
    }

    handleUpVote = () =>{
        this.props.onVote(this.props.id);
        }

    render() {
        return (
            <div className='item'>
                <div className='image'>
                    <img src={this.props.productImageUrl} />
                </div>
                <div className='middle aligned content'>
                    <div className='header'>
                        <a>
                            <i className='large caret up icon' />
                        </a>
                        {this.props.votes}
                    </div>
                    <div className='description'>
                        <a href={this.props.url}>
                            {this.props.title}
                        </a>
                        <p>
                            {this.props.description}
                        </p>
                    </div>
                    <div className='extra'>
                        <span>Submitted by:</span>
                        <img
                            className='ui avatar image'
                            src={this.props.submitterAvatarUrl}
                        />
                    </div>
                </div>
            </div>
        );
    }
}
  


Product.defaultProps = {
    //Khai báo giá trị mặc định cho props
   // id: 1,
   // title: 'Yellow Pail',
   // description: 'On-demand sand castle construction expertise.',
   // url: '#',
   // votes: 'generateVoteCount()',
   // submitterAvatarUrl: 'react/assets/images/daniel.jpg',
   // productImageUrl: 'react/assets/images/image-aqua.png'
}

export default Product;
