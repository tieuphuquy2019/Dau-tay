import React from 'react';
import ReactDOM from 'react-dom';
import Product from './Product';

export default  Product;
