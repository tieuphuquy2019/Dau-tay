import React from 'react';
//import 'bootstrap/dist/css/bootstrap'; 
//import { Button } from 'reactstrap';
import ReactDOM from 'react-dom';
//import '/bootstrap/dist/css/bootstrap.css';
//import 'bootstrap/dist/css/bootstrap.min.css';


class TimerForm extends React.Component {
 
    state = {
        title: this.props.title || '',
        project: this.props.project || '',
    };
}