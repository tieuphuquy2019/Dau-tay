import React from 'react';
import ReactDOM from 'react-dom';
import ProductList from './ProductList';

export default  ProductList;

