import React from 'react';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';


export default class bottom extends React.Component{



    render()
    {
        const html = ' <input id="timepicker" width={276} /> '
                  
        return <div>{ ReactHtmlParser(html) }</div>;
    }
}