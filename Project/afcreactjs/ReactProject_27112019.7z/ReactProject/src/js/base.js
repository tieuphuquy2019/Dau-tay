(function($){
        $('#dengio').timepicker({
            uiLibrary: 'bootstrap4',
             iconsLibrary: 'fontawesome',
        });
    
    
        $('#tugio').timepicker({
            uiLibrary: 'bootstrap4',
             iconsLibrary: 'fontawesome',
        });
}
    