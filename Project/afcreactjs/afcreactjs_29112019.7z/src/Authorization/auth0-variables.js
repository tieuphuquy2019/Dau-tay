/* global location */
export default {
  AUTH0_CLIENT_ID: 'pkwhjAq7e3t5TVTVJK0XioH0PaeZz8P6',
  AUTH0_DOMAIN: 'awolf.auth0.com',
  
}