import React from "react";

function PublicPage() {
    return <h3>Public</h3>;
  }
export default   PublicPage;