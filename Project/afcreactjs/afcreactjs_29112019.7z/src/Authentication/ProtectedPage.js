import React from "react";

function ProtectedPage() {
    return <h3>Protected fg</h3>;
  }
export default   ProtectedPage;