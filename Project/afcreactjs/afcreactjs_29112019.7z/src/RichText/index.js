import JoditEditor from './JoditEditor';

export default JoditEditor;