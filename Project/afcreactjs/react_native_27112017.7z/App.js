import React from 'react';

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';


import Example from './component/Example'
import Example_test from './component/Example_test'
import Screen1 from './component/Screen1'
import Screen2 from './component/Screen2'
import Screen3 from './component/Screen3'
import HomeScreen from "./component/HomeScreen";

import SearchBar from "./component/searchBar";

//import App_template from "./App_template.js";
import {StyleSheet,  Text, View } from 'react-native';

class App extends React.Component{

  render(){
    return(
      <View style={{flexDirection: 'row'}}>
      </View>
    );
  }

}


export default App;