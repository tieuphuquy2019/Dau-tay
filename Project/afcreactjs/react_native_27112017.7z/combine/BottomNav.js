
//This is an example code for Navigation Drawer with Custom Side bar//
import React, { Component } from 'react';
//import react in our code.
import {
  View,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Platform,
  Text,
} from 'react-native';
// import all basic components
 
//For React Navigation 3+
//import {
//  createStackNavigator,
//  createDrawerNavigator,
//  createAppContainer,
//} from 'react-navigation';
 
//For React Navigation 4+

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';

 
//Import all the screens
import Screen1 from '../component/Screen1';
import Screen2 from '../component/Screen2';
import Screen3 from '../component/Screen3';
import Screen4 from '../component/Screen4';
import Screen5 from '../component/Screen5';
import Menutop from '../component/menutop';

import DrawerNav from './DrawerNav';
import topNav from './topNav';
import Icon from 'react-native-vector-icons/Ionicons'; 

const FeedStack = createStackNavigator({
  Feed: {
    screen: Screen1,
    navigationOptions: {
      headerTitle: 'Feed',
    },
  },
  Details: {
    screen: Screen2,
    navigationOptions: {
      headerTitle: 'Details',
    },
  },
});

const SearchStack = createStackNavigator({
  Search: {
    screen: Screen2,
    navigationOptions: {
      headerTitle: 'Search',
    },
  },
  Details: {
    screen: Screen3,
    navigationOptions: {
      headerTitle: 'Details',
    },
  },
});

const DiscoverStack = createStackNavigator({
  Discover: {
    screen: Screen1,
    navigationOptions: {
      headerTitle: 'Discover',
    },
  },
  Details: {
    screen: Screen3,
    navigationOptions: {
      headerTitle: 'Details',
    },
  },
});
//-------------------------------------------------------------
const MainTabs = createBottomTabNavigator({
  
 
  Feed: {
    
    screen: FeedStack,
    screen: DrawerNav,
    screen: topNav,

    navigationOptions: {
      tabBarLabel: 'Feed',
      tabBarIcon:({tintColor})=>(  
              <Icon name="ios-home" color={tintColor} size={25}/>  
          )  
    },
  },
  Search: {
    
    screen: SearchStack,
    screen: topNav,
     screen: DrawerNav,
     
    navigationOptions: {
      tabBarLabel: 'Search',
      tabBarIcon:({tintColor})=>(  
              <Icon name="ios-person" color={tintColor} size={25}/>  
          )  
    },
  },
  Discover: {
    screen: DiscoverStack,
    navigationOptions: {
      tabBarLabel: 'Discover',
      tabBarIcon:({tintColor})=>(  
              <Icon name="ios-person" color={tintColor} size={25}/>  
          )  
     
    },
  }
},
 // navigator config
 {
  lazyLoad: true, // render the tabs lazily
  tabBarPosition: 'bottom', // where are the tabs shown
  backBehavior: 'none', // back button doesn't take you to the initial tab
  
},
{
  tabBarComponent: props =>{
      return(
          <View style={{backgroundColor:"black"}}> 
          <Image
              style={{ width:'100%', height: 80 }}
              source={ require('../image/bottom_btn.png')} />
          </View>
      );
  }
},
 {
    tabBarOptions: {
        activeTintColor: '#6BBDFE',
        inactiveTintColor: 'gray',
        style: {
            backgroundColor: '#6BBDFE',
        },
        indicatorStyle: {
            backgroundColor: '#6BBDFE',
        },
    }
}
);

export default createAppContainer(MainTabs);
//----------------------------------------------------------