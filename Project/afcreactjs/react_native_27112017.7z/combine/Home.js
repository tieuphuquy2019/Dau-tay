import React from 'react';
import { View, Image, TouchableOpacity,Button, Text } from 'react-native';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';




//------------------------------------------------------------



class Home extends React.Component{
    render(){
        return(
            <View>
                <Text>asdas</Text>
               
            </View>
        )
    }
}

export default Home;