
//This is an example code for Navigation Drawer with Custom Side bar//
import React, { Component } from 'react';
//import react in our code.
import {
  View,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Platform,
  Text,
} from 'react-native';
// import all basic components
 
//For React Navigation 3+
//import {
//  createStackNavigator,
//  createDrawerNavigator,
//  createAppContainer,
//} from 'react-navigation';
 
//For React Navigation 4+

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';
import { DrawerActions } from 'react-navigation';
 
//Import all the screens
import Screen1 from '../component/Screen1';
import Screen2 from '../component/Screen2';
import Screen3 from '../component/Screen3';
import Screen4 from '../component/Screen4';
import Screen5 from '../component/Screen5';
import Menutop from '../component/menutop';
import Example from '../component/Example';

import DrawerNav from './DrawerNav';
import Icon from 'react-native-vector-icons/Ionicons'; 

//----------------------------------------------------------

const MainTop = createMaterialTopTabNavigator({
    Feed: {
      screen: Screen1,
      navigationOptions: {
        tabBarLabel: 'Feed',
        // tabBarIcon: ({ tintColor }) => (
        //  <Icon name="ios-person" color={tintColor} size={25}/>  
        // )
      },
    },
    Search: {
      screen: Screen2,
      title: 'Search',
      navigationOptions: {
        tabBarLabel: 'Search',
        // tabBarIcon: ({ tintColor }) => (
        //  <Icon name="ios-person" color={tintColor} size={25}/>  
        // ) 
      },
    },
    Discover: {
      screen: Screen3,
      navigationOptions: {
        tabBarLabel: 'Discover',
         tabBarIcon:({tintColor})=>(  
              <Icon name="ios-person" color={tintColor} size={25}/>  
          )  
      },
    },
    Events: {
      screen: Screen4,
      navigationOptions: {
        tabBarLabel: 'events',
         tabBarIcon: ({ tintColor }) => (
         <Icon name="ios-person" color={tintColor} size={25}/>  
        ) 
      },
    },
  },
  {
    tabBarPosition: 'top',
    swipeEnabled: true,
    
     defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, horizontal, tintColor }) => {
        const { routeName } = navigation.state;
        if (routeName === 'Feed') {
          return (
            <Image
              source={
                focused
                  ? require('../image/logo1.png')
                  : require('../image/logo2.png')
              }
              style={{
                width: 20,
                height: 20,
                borderRadius: 40 / 2,
              }}
            />
          );
        } else if (routeName === 'Search') {
          return (
            <Image
              source={
                focused
                  ? require('../image/logo3.png')
                  : require('../image/logo4.png')
              }
              style={{
                width: 20,
                height: 20,
                borderRadius: 40 / 2,
              }}
            />
          );
        }
      },
    }),

    tabBarOptions: {
        activeTintColor: '#000',
         showIcon: true,  
          // showLabel:false,  
        inactiveTintColor: 'gray',
        style: {
            backgroundColor: '#FF9800',
        },
        indicatorStyle: {
             backgroundColor:'red'
        },
    }
}
  );


  export default createAppContainer(MainTop);