//This is an example code for Navigation Drawer with Custom Side bar//
import React, { Component } from 'react';
//import react in our code.
import {
  View,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Platform,
  Text,
  ScrollView,
} from 'react-native';
// import all basic components
 
//For React Navigation 3+
//import {
//  createStackNavigator,
//  createDrawerNavigator,
//  createAppContainer,
//} from 'react-navigation';
 
//For React Navigation 4+

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';

 
//Import all the screens
import Screen1 from '../component/Screen1';
import Screen2 from '../component/Screen2';
import Screen3 from '../component/Screen3';
import Screen4 from '../component/Screen4';
import Screen5 from '../component/Screen5';
import Screen6 from '../component/Screen6';
import Menutop from '../component/menutop';

import Screen7 from '../component/Screen7';
import Screen8 from '../component/Screen8';
import Screen9 from '../component/Screen9';
import Screen10 from '../component/Screen10';
import Screen11 from '../component/Screen11';
import Screen12 from '../component/Screen12';



import Screen13 from '../component/Screen13';
import Screen14 from '../component/Screen14';
import Screen15 from '../component/Screen15';
import Screen16 from '../component/Screen16';
import Screen17 from '../component/Screen17';
import Screen18 from '../component/Screen18';


import Screen19 from '../component/Screen19';
import Screen20 from '../component/Screen20';
import Screen21 from '../component/Screen21';
import Screen22 from '../component/Screen22';
import Screen23 from '../component/Screen23';
import Screen24 from '../component/Screen24';


import Screen25 from '../component/Screen25';
import Screen26 from '../component/Screen26';
import Screen27 from '../component/Screen27';
import Screen28 from '../component/Screen28';
import Screen29 from '../component/Screen29';
import Screen30 from '../component/Screen30';

import Screen31 from '../component/Screen31';
import Screen32 from '../component/Screen32';
import Screen33 from '../component/Screen33';
import Screen34 from '../component/Screen34';
import Screen35 from '../component/Screen35';
import Screen36 from '../component/Screen36';
import Screen37 from '../component/Screen37';
import Screen38 from '../component/Screen38';
import Screen39 from '../component/Screen39';
import Screen40 from '../component/Screen40';

import Icon from 'react-native-vector-icons/Ionicons'; 
 
//Import Custom Sidebar
import CustomSidebarMenu from './MySideBar';
import TopNav from './topNav';
import ImageCar from '../carousel/imageCar';

global.currentScreenIndex = 0;
//Navigation Drawer Structure for all screen
class NavigationDrawerStructure extends Component {
  //Top Navigation Header with Donute Button
  toggleDrawer = () => {
    //Props to open/close the drawer
    this.props.navigationProps.toggleDrawer();
  };
  render() {
    return (
      <View style={{ flexDirection: 'row' }}>
        <TouchableOpacity onPress={this.toggleDrawer.bind(this)}>
          {/*Donute Button Image */}
          <Image
            source={require('../image/drawer.png')}
            style={{ width: 35, height: 25, marginLeft: 5 }}
          />
        </TouchableOpacity>
      </View>
    );
  }
}
 
//Stack Navigator for the First Option of Navigation Drawer
const FirstActivity_StackNavigator = createStackNavigator({
  //All the screen from the First Option will be indexed here
  First: {
    screen: TopNav,
      navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 1',
      headerBackTitle: null,
      headerTruncatedBackTitle: `to A`,
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerRight:(
          < Icon name="ios-home" size={30} style={{marginStart:10}} backgroundColor="#000000" onPress={() => navigation.openDrawer()} >< /Icon>
        ),
      tabBarIcon: ({ tintColor }) => <Icon name="home" size={28} color={tintColor} type={"font-awesome"} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
      
      // header: (props) => <ImageCar {...props} />,
      
    }),
  },
});
 
//Stack Navigator for the Second Option of Navigation Drawer
const Screen2_StackNavigator = createStackNavigator({
  //All the screen from the Second Option will be indexed here
  Second: {
    screen: Screen2,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 2',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});
 
//Stack Navigator for the Third Option of Navigation Drawer
const Screen3_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  Third: {
    screen: Screen3,
    screen:ImageCar,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 3',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
      
    }),
   
  },
   
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen4_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  Four: {
    screen: Screen4,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 4',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen5_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  Five: {
    screen: Screen5,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 5',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen6_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  Six: {
    screen: Screen6,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 6',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});
 

//Stack Navigator for the Third Option of Navigation Drawer
const Screen7_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  bay: {
    screen: Screen7,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 7',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen8_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  tam: {
    screen: Screen8,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 8',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen9_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  chin: {
    screen: Screen9,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 9',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen10_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoi: {
    screen: Screen10,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 10',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen11_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoimot: {
    screen: Screen11,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 11',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen12_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoihai: {
    screen: Screen12,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen13_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoiba: {
    screen: Screen13,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 13',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen14_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoibon: {
    screen: Screen14,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 14',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen15_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoilam: {
    screen: Screen15,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 15',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen16_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoisau: {
    screen: Screen16,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 16',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen17_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoibay: {
    screen: Screen17,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 17',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen18_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoitam: {
    screen: Screen18,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 18',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen19_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  muoichin: {
    screen: Screen19,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 19',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});

//Stack Navigator for the Third Option of Navigation Drawer
const Screen20_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haimuoi: {
    screen: Screen20,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 20',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen21_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haimot: {
    screen: Screen21,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 21',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});



//Stack Navigator for the Third Option of Navigation Drawer
const Screen22_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haihai: {
    screen: Screen22,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 22',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});



//Stack Navigator for the Third Option of Navigation Drawer
const Screen23_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haiba: {
    screen: Screen23,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 23',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});



//Stack Navigator for the Third Option of Navigation Drawer
const Screen24_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haibon: {
    screen: Screen24,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 24',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});



//Stack Navigator for the Third Option of Navigation Drawer
const Screen25_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  hailam: {
    screen: Screen25,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 25',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});



//Stack Navigator for the Third Option of Navigation Drawer
const Screen26_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haisau: {
    screen: Screen26,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 26',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});



//Stack Navigator for the Third Option of Navigation Drawer
const Screen27_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haibay: {
    screen: Screen27,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 27',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});



//Stack Navigator for the Third Option of Navigation Drawer
const Screen28_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haitam: {
    screen: Screen28,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});









//Stack Navigator for the Third Option of Navigation Drawer
const Screen29_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  haichin: {
    screen: Screen29,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 29',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen30_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  bamuoi: {
    screen: Screen30,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen31_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  bamot: {
    screen: Screen31,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen32_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  bahai: {
    screen: Screen32,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen33_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  baba: {
    screen: Screen33,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen34_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  babon: {
    screen: Screen34,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen35_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  balam: {
    screen: Screen35,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen36_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  basau: {
    screen: Screen36,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 36',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen37_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  babay: {
    screen: Screen37,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen38_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  batam: {
    screen: Screen38,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen39_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  bachin: {
    screen: Screen39,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});


//Stack Navigator for the Third Option of Navigation Drawer
const Screen40_StackNavigator = createStackNavigator({
  //All the screen from the Third Option will be indexed here
  bonmuoi: {
    screen: Screen40,
    navigationOptions: ({ navigation }) => ({
      title: 'Demo Screen 12',
      headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
      headerStyle: {
        backgroundColor: '#FF9800',
      },
      headerTintColor: '#fff',
    }),
  },
});






 //--------------------------------------------------------------
//Drawer Navigator Which will provide the structure of our App
const DrawerNavigatorExample = createDrawerNavigator(
  {
    
    NavScreen1: {
      screen: FirstActivity_StackNavigator,
      
      navigationOptions: {
        drawerLabel: 'Demo Screen 1',
      },
    },
    NavScreen2: {
      screen: Screen2_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 2',
      },
    },
    NavScreen3: {
      screen: Screen3_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 3',
      },
    },
    NavScreen4: {
      screen: Screen4_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 4',
      },
    },
    NavScreen5: {
      screen: Screen5_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 5',
      },
    },

    NavScreen6: {
      screen: Screen6_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 6',
      },
    },

     NavScreen7: {
      screen: Screen7_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 7',
      },
    },

     NavScreen8: {
      screen: Screen8_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 8',
      },
    },

     NavScreen9: {
      screen: Screen9_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 9',
      },
    },

     NavScreen10: {
      screen: Screen10_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 10',
      },
    },

     NavScreen11: {
      screen: Screen11_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 11',
      },
    },

     NavScreen12: {
      screen: Screen12_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 12',
      },
    },

    NavScreen13: {
      screen: Screen13_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 13',
      },
    },

    NavScreen14: {
      screen: Screen14_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 14',
      },
    },

    NavScreen15: {
      screen: Screen15_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 15',
      },
    },

    NavScreen16: {
      screen: Screen16_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 16',
      },
    },

    NavScreen17: {
      screen: Screen17_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 17',
      },
    },

    NavScreen18: {
      screen: Screen18_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 18',
      },
    },

    NavScreen19: {
      screen: Screen19_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 19',
      },
    },

    NavScreen20: {
      screen: Screen20_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 20',
      },
    },

    NavScreen21: {
      screen: Screen21_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 21',
      },
    },

    NavScreen22: {
      screen: Screen22_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 22',
      },
    },

    NavScreen23: {
      screen: Screen23_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 23',
      },
    },

    NavScreen24: {
      screen: Screen24_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 24',
      },
    },

    NavScreen25: {
      screen: Screen25_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 25',
      },
    },

    NavScreen26: {
      screen: Screen26_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 26',
      },
    },

    NavScreen27: {
      screen: Screen27_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 27',
      },
    },

    
    NavScreen28: {
      screen: Screen28_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },

 NavScreen29: {
      screen: Screen29_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },


 NavScreen30: {
      screen: Screen30_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },


 NavScreen31: {
      screen: Screen31_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },


 NavScreen32: {
      screen: Screen32_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },


 NavScreen33: {
      screen: Screen33_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },

 NavScreen34: {
      screen: Screen34_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },

 NavScreen35: {
      screen: Screen35_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },

 NavScreen36: {
      screen: Screen36_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },

 NavScreen37: {
      screen: Screen37_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },

 NavScreen38: {
      screen: Screen38_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },

 NavScreen39: {
      screen: Screen39_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },

 NavScreen40: {
      screen: Screen40_StackNavigator,
      navigationOptions: {
        drawerLabel: 'Demo Screen 28',
      },
    },


   
  },
  {
    //For the Custom sidebar menu we have to provide our CustomSidebarMenu
    contentComponent: CustomSidebarMenu,
    //Sidebar width
    drawerWidth: Dimensions.get('window').width - 130,
    initialRouteName: 'NavScreen1',
    
    //-------------------------------------------------------------
  }
);

 export default createAppContainer(DrawerNavigatorExample);

