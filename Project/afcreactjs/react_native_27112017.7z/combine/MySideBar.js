//This is an example code for Navigation Drawer with Custom Side bar//
import React, { Component } from 'react';
import { View, StyleSheet, Image, Text,ScrollView } from 'react-native';
import { Icon } from 'react-native-elements';
import PropTypes from 'prop-types';
 
export default class CustomSidebarMenu extends Component {
  constructor() {
    super();
    //Setting up the Main Top Large Image of the Custom Sidebar
    this.proileImage =
      'https://homepages.cae.wisc.edu/~ece533/images/airplane.png';
    //Array of the sidebar navigation option with icon and screen to navigate
    //This screens can be any screen defined in Drawer Navigator in App.js
    //You can find the Icons from here https://material.io/tools/icons/
    this.items = [
      {
        navOptionThumb: 'camera',
        navOptionName: 'First Screen',
        screenToNavigate: 'NavScreen1',
      },
      {
        navOptionThumb: 'home',
        navOptionName: 'Second Screen',
        screenToNavigate: 'NavScreen2',
      },
      {
        navOptionThumb: 'image',
        navOptionName: 'Third Screen',
        screenToNavigate: 'NavScreen3',
      },
      {
        navOptionThumb: 'build',
        navOptionName: 'Fourth Screen',
        screenToNavigate: 'NavScreen4',
      },
      {
        navOptionThumb: 'info',
        navOptionName: 'fiveth Screen',
        screenToNavigate: 'NavScreen5',
      },

       {
        navOptionThumb: 'home',
        navOptionName: 'Sixth Screen',
        screenToNavigate: 'NavScreen6',
      },

         {
        navOptionThumb: 'home',
        navOptionName: '7 Screen',
        screenToNavigate: 'NavScreen7',
      },

         {
        navOptionThumb: 'home',
        navOptionName: '8 Screen',
        screenToNavigate: 'NavScreen8',
      },

         {
        navOptionThumb: 'home',
        navOptionName: '9 Screen',
        screenToNavigate: 'NavScreen9',
      },

         {
        navOptionThumb: 'home',
        navOptionName: '10 Screen',
        screenToNavigate: 'NavScreen10',
      },

         {
        navOptionThumb: 'home',
        navOptionName: '11 Screen',
        screenToNavigate: 'NavScreen11',
      },

         {
        navOptionThumb: 'home',
        navOptionName: '12 Screen',
        screenToNavigate: 'NavScreen12',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '13 Screen',
        screenToNavigate: 'NavScreen13',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '14 Screen',
        screenToNavigate: 'NavScreen14',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '15 Screen',
        screenToNavigate: 'NavScreen15',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '16 Screen',
        screenToNavigate: 'NavScreen16',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '17 Screen',
        screenToNavigate: 'NavScreen17',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '18 Screen',
        screenToNavigate: 'NavScreen18',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '19 Screen',
        screenToNavigate: 'NavScreen19',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '20 Screen',
        screenToNavigate: 'NavScreen20',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '21 Screen',
        screenToNavigate: 'NavScreen21',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '22 Screen',
        screenToNavigate: 'NavScreen22',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '23 Screen',
        screenToNavigate: 'NavScreen23',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '24 Screen',
        screenToNavigate: 'NavScreen24',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '25 Screen',
        screenToNavigate: 'NavScreen25',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '26 Screen',
        screenToNavigate: 'NavScreen26',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '27 Screen',
        screenToNavigate: 'NavScreen27',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '28 Screen',
        screenToNavigate: 'NavScreen28',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '29 Screen',
        screenToNavigate: 'NavScreen29',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '30 Screen',
        screenToNavigate: 'NavScreen30',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '31 Screen',
        screenToNavigate: 'NavScreen31',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '31 Screen',
        screenToNavigate: 'NavScreen31',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '32 Screen',
        screenToNavigate: 'NavScreen32',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '33 Screen',
        screenToNavigate: 'NavScreen33',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '34 Screen',
        screenToNavigate: 'NavScreen34',
      },
      
         {
        navOptionThumb: 'home',
        navOptionName: '35 Screen',
        screenToNavigate: 'NavScreen35',
      },

      
         {
        navOptionThumb: 'home',
        navOptionName: '36 Screen',
        screenToNavigate: 'NavScreen36',
      },
      
         {
        navOptionThumb: 'home',
        navOptionName: '37 Screen',
        screenToNavigate: 'NavScreen37',
      },
      
         {
        navOptionThumb: 'home',
        navOptionName: '38 Screen',
        screenToNavigate: 'NavScreen38',
      },
      
         {
        navOptionThumb: 'home',
        navOptionName: '39 Screen',
        screenToNavigate: 'NavScreen39',
      },

       {
        navOptionThumb: 'home',
        navOptionName: '40 Screen',
        screenToNavigate: 'NavScreen40',
      },


    ];
  }
  render() {
    return (
      <View style={{ flexDirection: 'row' }}>
        <ScrollView>
          <View>
            <View style={styles.sideMenuContainer}>
              {/*Top Large Image */}
              <Image
                source={{ uri: this.proileImage }}
                style={styles.sideMenuProfileIcon}
              />
              {/*Divider between Top Image and Sidebar Option*/}
              <View
                style={{
                  width: '100%',
                  height: 1,
                  backgroundColor: '#AAAAAA',
                  marginTop: 15,
                }}
              />
              {/*Setting up Navigation Options from option array using loop*/}
              <View style={{ width: '100%' }}>
                {this.items.map((item, key) => (
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      paddingTop: 10,
                      paddingBottom: 10,
                      backgroundColor: global.currentScreenIndex === key ? '#e0dbdb' : '#ffffff',
                      
                    }}
                    key={key}>
                    <View style={{ marginRight: 10, marginLeft: 20 }}>
                      <Icon name={item.navOptionThumb} size={25} color="#808080" />
                    </View>
                    <Text
                      style={{
                        fontSize: 15,
                        color: global.currentScreenIndex === key ? 'red' : 'black',
                      }}
                      onPress={() => {
                        global.currentScreenIndex = key;
                        this.props.navigation.navigate(item.screenToNavigate);
                      }}>
                      {item.navOptionName}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
            </View>
        </ScrollView>
      </View>
    );
  }
}

CustomSidebarMenu.propTypes = {
  navigation: PropTypes.object
};


const styles = StyleSheet.create({
  sideMenuContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    alignItems: 'center',
    paddingTop: 20,
  },
  sideMenuProfileIcon: {
    resizeMode: 'center',
    width: 150,
    height: 150,
    marginTop: 20,
    borderRadius: 150 / 2,
    
  },
});