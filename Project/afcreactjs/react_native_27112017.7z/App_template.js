import React from 'react';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';


import Example from './component/Example'
import Example_test from './component/Example_test'
import Screen1 from './component/Screen1'
import Screen2 from './component/Screen2'
import Screen3 from './component/Screen3'




const AuthStack = createStackNavigator({


  Landing: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Landing',
    },
  },
  SignIn: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Sign In',
    },
  },
  CreateAccount: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Create Account',
    },
  },
  ForgotPassword: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Forgot Password',
    },
  },
  ResetPassword: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Reset Password',
    },
  },
});


const FeedStack = createStackNavigator({
  Feed: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Feed',
    },
  },
  Details: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Details',
    },
  },
});

const SearchStack = createStackNavigator({
  Search: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Search',
    },
  },
  Details: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Details',
    },
  },
});

const DiscoverStack = createStackNavigator({
  Discover: {
    screen: Screen1,
    navigationOptions: {
      headerTitle: 'Discover',
    },
  },
  Details: {
    screen: Screen3,
    navigationOptions: {
      headerTitle: 'Details',
    },
  },
});

//-------------------------------------------------------------
const MainTabs = createBottomTabNavigator({
  Feed: {
    screen: FeedStack,
    navigationOptions: {
      tabBarLabel: 'Feed',
    },
  },
  Search: {
    screen: SearchStack,
    navigationOptions: {
      tabBarLabel: 'Search',
    },
  },
  Discover: {
    screen: DiscoverStack,
    navigationOptions: {
      tabBarLabel: 'Discover',
    },
  },
});


//----------------------------------------------------------

const MainTop = createMaterialTopTabNavigator({
    Feed: {
      screen: Example,
      navigationOptions: {
        tabBarLabel: 'Feed',
      },
    },
    Search: {
      screen: Example,
      navigationOptions: {
        tabBarLabel: 'Search',
      },
    },
    Discover: {
      screen: Example,
      navigationOptions: {
        tabBarLabel: 'Discover',
      },
    },
    Events: {
      screen: Screen2,
      navigationOptions: {
        tabBarLabel: 'events',
      },
    },
  });


//-------------------------------------------------
const SettingsStack = createStackNavigator({
  SettingsList: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Settings List',
    },
  },
  Profile: {
    screen: Example,
    navigationOptions: {
      headerTitle: 'Profile',
    },
  },
});

const MainDrawer = createDrawerNavigator({
  MainTabs: MainTabs,
  Settings: SettingsStack,
});

const AppModalStack = createStackNavigator(
  {
    App: MainDrawer,
    Promotion1: {
      screen: Example,
    },
  },
  {
    mode: 'modal',
    headerMode: 'none',
  }
);

const App_template = createSwitchNavigator({
  Loading: {
    screen: Example,
  },
  Top: {
    screen: MainTop,
  },
  Auth: {
    screen: AuthStack,
  },
  Bottom: {
    screen: MainTabs,
  },
  MainDrawer: {
    screen: AppModalStack,
  },
});

export default createAppContainer(App_template);