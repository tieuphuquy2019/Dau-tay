//This is an example code for Navigation Drawer with Custom Side bar//
import React, { Component } from 'react';
//import react in our code.
import {
  View,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Platform,
  Text,
} from 'react-native';
// import all basic components
 
//For React Navigation 3+
//import {
//  createStackNavigator,
//  createDrawerNavigator,
//  createAppContainer,
//} from 'react-navigation';
 
//For React Navigation 4+

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';

 
//Import all the screens
import Screen1 from './component/Screen1';
import Screen2 from './component/Screen2';
import Screen3 from './component/Screen3';
import Screen4 from './component/Screen4';
import Screen5 from './component/Screen5';
import Menutop from './component/menutop';
 
//Import Custom Sidebar
import Home from './combine/Home';
import DrawerNav from './combine/DrawerNav';
import BottomNav from './combine/BottomNav';
import BottomSlide from './carousel/bottomSlide';

import ImageCar from './carousel/imageCar';


//-------------------------------------


const Menu = createSwitchNavigator({
  
  Home: {
    screen: Home,
    
  },

  Top: {
    screen: DrawerNav,
  },

  Bottom: {
    screen: BottomNav,
   
  },
  
},
{
  initialRouteName: "Bottom"
}
);

export default createAppContainer(Menu);
