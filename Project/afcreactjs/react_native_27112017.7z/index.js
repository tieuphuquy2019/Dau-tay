/**
 * @format
 */

import {AppRegistry} from 'react-native';
import App from './App';
import App_template from './App_template';
import App_menu from './App_menu';
import App_menu1 from './App_menu1';
import App_menu2 from './App_menu2';
import App_menu3 from './App_menu3';
import App_menu4 from './App_menu4';
import {name as appName} from './app.json';

AppRegistry.registerComponent(appName, () => App_menu2);

