import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, TouchableOpacity, Image } from 'react-native';


import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';

import ImageCar from './carousel/imageCar';
import Sliding_up_down from './carousel/sliding_up_down';
import ButtonGroup from './group/buttonGroup';
import Flexbox from './group/flexbox';


export default class App extends React.Component{

  render(){
      return(

            
              <Flexbox />

      );

  }
}