import React, { Component } from 'react';
const WebViewAndroid = require('react-native-webview-rtc');
import {
    View,
    StyleSheet,
    Dimensions,
    Image,
    TouchableOpacity,
    Platform,
    Text,
  } from 'react-native';
var SITE_URL = 'https://react-native-webrtc.herokuapp.com';
var URL_DOMAIN = 'react-native-webrtc.herokuapp.com';
 
// inside react class
export default class AAa extends React.Component{



constructor(props){
    super(props);
    this.state = {
                url: SITE_URL,
                status: 'No Page Loaded',
                backButtonEnabled: false,
                forwardButtonEnabled: false,
                loading: true,
                messageFromWebView: null
        }
}
 
goBack() {
  // you can use this callback to control web view
  this.refs.webViewAndroidSample.goBack();
}
 
goForward() {
  this.refs.webViewAndroidSample.goForward();
}
reload () {
  this.refs.webViewAndroidSample.reload();
}
 
stopLoading () {
  // stops the current load
  this.refs.webViewAndroidSample.stopLoading();
}
 
postMessage (data) {
  // posts a message to web view
  this.refs.webViewAndroidSample.postMessage(data);
}
 
evaluateJavascript (data) {
  // evaluates javascript directly on the webview instance
  this.refs.webViewAndroidSample.evaluateJavascript(data);
}
 
injectJavaScript (script) {
  // executes JavaScript immediately in web view
  this.refs.webViewAndroidSample.injectJavaScript(script);
}
 
onShouldStartLoadWithRequest (event) {
 
  console.log('App.js -> onShouldStartLoadWithRequest () ...');
  // currently only url & navigationState are returned
 
  console.log('event.url = ', event.url);
  console.log('navigatinalstate = ', event.navigationState);
 
    if (event.url.indexOf({URL_DOMAIN} >=0 )) {
      return true;
    } else {
      return false;
    }
}
 
onNavigationStateChange = (event) => {
    console.log('App.js -> onNavigationStateChange () ...');
    console.log(event);
    this.setState({
      forwardButtonEnabled: event.canGoForward,
      backButtonEnabled: event.canGoBack,
      loading: event.loading,
      url: event.url,
      status: event.title
    });
}
 
onMessage (event) {
    console.log('App.js -> onMessage () ...');
    this.setState({
        messageFromWebView: event.message
    });
}
 
javascriptToInject () {
    return `
      $(document).ready(function() {
        $('a').click(function(event) {
          if ($(this).attr('href')) {
            var href = $(this).attr('href');
            window.webView.postMessage('Link tapped: ' + href);
          }
        })
      })
    `
}
 
render() {
  return (
    <WebViewAndroid
      ref="webViewAndroidSample"
      javaScriptEnabled={true}
      javaScriptEnabledAndroid={true}
      geolocationEnabled={false}
      builtInZoomControls={false}
      mediaPlayUserGesture={false}
      injectedJavaScript={this.javascriptToInject()}
      onShouldStartLoadWithRequest={this.onShouldStartLoadWithRequest}
      onNavigationStateChange={this.onNavigationStateChange}
      onMessage={this.onMessage}
      url={SITE_URL}
      style={styles.containerWebView}
    />
  );
}
 
}
const styles = StyleSheet.create({
  containerWebView: {
      flex: 1,
  },
});