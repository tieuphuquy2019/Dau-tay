import React, { Component } from 'react';
import ButtonGroup from './buttonGroup';


import {
  StyleSheet,
  Text,
  View
} from 'react-native';

export default class App extends Component {
  render() {
    return (
      <View style={styles.container}>
      
      <ButtonGroup />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 10,
    backgroundColor: '#F5FCFF',
    height:20,
   
  },
  
});