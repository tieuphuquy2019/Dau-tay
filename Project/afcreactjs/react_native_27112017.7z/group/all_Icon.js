

import React, { Component } from 'react';
import {Container, Content, Card, CardItem, Thumbnail,  Button , Header, Title ,Footer, Icon , Badge } from 'native-base';
import {
    View,
    StyleSheet,
    Dimensions,
    Image,
    TouchableOpacity,
    Platform,
    Text,
    Br,
  } from 'react-native';

//   import Icon from 'react-native-vector-icons/Ionicons'; 
  import { SocialIcon } from 'react-native-elements';

export default class ListThumbnailExample extends Component {
    render() {
        return (
            <Container>
                <Content>
                    <Badge>2</Badge>
                    <Badge primary>2</Badge>
                    <Badge success>2</Badge>
                    <Badge info>2</Badge>
                    <Badge warning>2</Badge>
                    <Badge danger>2</Badge>
                </Content>
            </Container>
        );
    }
}