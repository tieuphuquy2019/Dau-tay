'use strict';

//This is an example code for NavigationDrawer//
import React, { Component } from 'react';
//import react in our code.
import { StyleSheet, View, Text,ScrollView } from 'react-native';

import CardView from 'react-native-cardview';

import { Card } from 'react-native-elements';

export default class App extends React.Component {
  render() {
    return (
       
       
            <View style={styles.container}>
                
                <Card title="Local Modules">
                {/*react-native-elements Card*/}
                <Text style={styles.paragraph}>
                    This is a card from the react-native-elements
                </Text>
                </Card>
           </View>
       
         
     
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 40,
    backgroundColor: '#ecf0f1',
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#34495e',
  },
});