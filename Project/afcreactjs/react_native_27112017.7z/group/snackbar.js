//This is an example of React Native SnackBar// 
import React, { Component } from 'react';
//import react in our code. 
import { AppRegistry, StyleSheet, Text, View, Button } from 'react-native';
//import all the components we are going to use.
import Snackbar from 'react-native-snackbar-component';
//import Snackbar
 
export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      snackIsVisible: false,
      //Setting up the starting visible state of snackbar
      distance: 0,
    };
  }
 
  render() {
    return (
      <View style={styles.container}>
        <Button
          onPress={() => {
            this.setState({ 
              snackIsVisible: !this.state.snackIsVisible
            });
          }}
          title="show snackbar"
          color="#841584"
          accessibilityLabel="toggle"
        />
        <Snackbar
          visible={this.state.snackIsVisible}
          //SnackBar visibility control
          textMessage="This is Snackbar"
          //Text on SnackBar
          actionHandler={() => {
            //function called while clicking on action Text
            alert("let's go");
            //After handling click making nackBar invisible
            this.setState({ 
              snackIsVisible: !this.state.snackIsVisible 
            });
          }}
          actionText="let's go"
          //action Text to print on SnackBar
          distanceCallback={distance => {
            //Number indicating distance taken up by snackbar
            this.setState({ distance: distance });
          }}
        />
      </View>
    );
  }
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
});