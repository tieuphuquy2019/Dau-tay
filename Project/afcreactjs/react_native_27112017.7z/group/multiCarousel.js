import React, { Component } from 'react';
import { View, StyleSheet,Text } from 'react-native';

import Carousel from 'react-native-snap-carousel';

// You can import from local files
import { sliderWidth, sliderItemWidth } from './styles';
import Card from './Card';

export default class App extends Component {
  state = {
    data: [
      {
        title: '1'
      },
      {
        title: '2'
      },
      {
        title: '3'
      },
      {
        title: '4'
      },
    ],
  };

  renderListComponent = ({ item }) => (
    <Card title={item.title} />
  );

  render() {
    return (
            <View  style={styles.container}>
                 <Text style={styles.sanpham}>Sản phẩm bán chạy</Text>   
                <Carousel
                data={this.state.data}
                renderItem={this.renderListComponent}
                sliderWidth={sliderWidth}
                itemWidth={sliderItemWidth}
                activeSlideAlignment={'start'}
                inactiveSlideScale={1}
                inactiveSlideOpacity={1}
                />
            </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    // flex: 1,
    // paddingTop: 56,
    // backgroundColor: '#FFFFFF',
    margin: 10,
    marginTop: -5,
    // paddingHorizontal:20,
    // paddingVertical:40,
    // marginTop:20
  },
  container1: {
    flex: 1,
    marginTop: 10,
    backgroundColor: '#F5FCFF',
    height:20,
  },
  sanpham: {
    // flex: 1,
    // paddingTop: 56,
    backgroundColor: '#FFFFFF',
    fontSize: 20,
    paddingLeft: 10,
    // marginTop:-50
  },
});

