//This is an example code for Navigation Drawer with Custom Side bar//
import React, { Component } from 'react';
//import react in our code.
import {
  View,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Platform,
  Text,
  Br,
} from 'react-native';
// import all basic components
 
//For React Navigation 3+
//import {
//  createStackNavigator,
//  createDrawerNavigator,
//  createAppContainer,
//} from 'react-navigation';
 
//For React Navigation 4+

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';


export default class App extends Component{
  render() {
    return (
      <View style={styles.container}>
            <Text style={styles.danhmuc}>Danh mục</Text>
            <View  style={{flexDirection: "row"}}>
              <TouchableOpacity style={styles.button1}>
                <Text >A</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.button1}>
                <Text>B</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.button1}>
                <Text >A</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.button1}>
                <Text>B</Text>
              </TouchableOpacity>
          </View>
          <Text>{"\n"}</Text>
          <View  style={{flexDirection: "row"}}>
              <TouchableOpacity style={styles.button2}>
                <Text >A</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.button2}>
                <Text>B</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.button2}>
                <Text >A</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.button2}>
                <Text>B</Text>
              </TouchableOpacity>
          </View>
      </View>


    );
  }
}

const styles = StyleSheet.create({
  button1:{
    paddingHorizontal:20,
    paddingVertical:12,
    backgroundColor:'#c37dc6',
    marginRight:50,
    borderRadius:8,
    justifyContent: 'center',
    alignItems: 'center',
    width:50,
    marginTop:-15
    
  },
  button2:{
    paddingHorizontal:20,
    paddingVertical:12,
    backgroundColor:'grey',
    marginRight:50,
    borderRadius:8,
    justifyContent: 'center',
    alignItems: 'center',
    width:50,
    marginTop:-15
    
  },
  container: {
    // flex: 1,
    // flexDirection: 'row',
    // justifyContent: 'center',
    // alignItems: 'center',
    // backgroundColor: 'orange',

    flex: 1,
    
    backgroundColor: '#FFFFFF',
    margin: 10,
    textAlign: 'center',
    fontSize: 20,
    paddingTop: 20,
    paddingLeft:20,
    
  },

 
    welcome: {
      flex: 1,
      margin: 20,
      backgroundColor: '#c37dc6',
     
    },

    danhmuc: {
        margin: 20,
        marginTop: -10,        
        marginLeft:-5,
        fontSize: 20,
       
      },
});