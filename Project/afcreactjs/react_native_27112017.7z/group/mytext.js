//This is an example code for Navigation Drawer with Custom Side bar//
import React, { Component } from 'react';
//import react in our code.
import {
  View,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Platform,
  Text,
} from 'react-native';
// import all basic components
 
//For React Navigation 3+
//import {
//  createStackNavigator,
//  createDrawerNavigator,
//  createAppContainer,
//} from 'react-navigation';
 
//For React Navigation 4+

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';

import MultiCarousel from './multiCarousel';


export default class App extends Component{
    render() {
        return (
          <View style={styles.container}>
            
                <Text style={styles.welcome}>Ưu đãi đặc biệt</Text>
                <MultiCarousel />
          </View>
        );
      }
}

const styles = StyleSheet.create({
 
  container: {
    // flex: 1,
    // flexDirection: 'row',
    // justifyContent: 'center',
    // alignItems: 'center',
    // backgroundColor: 'orange',

    flex: 1,
    backgroundColor: '#F5FCFF',
    // margin: 10,
  
  },

 
    welcome: {
      flex: 1,
      margin:10,
      marginTop:-3,
      backgroundColor: '#FFFFFF',
      textAlign: 'left',
      fontSize: 20,
      paddingTop: -10,
      paddingLeft:20,
    },

   
});