'use strict';

//This is an example code for NavigationDrawer//
import React, { Component } from 'react';
//import react in our code.
import { StyleSheet, View, Text,ScrollView } from 'react-native';

import CardView from 'react-native-cardview';

import { Card } from 'react-native-elements';


import MyCard from '../group/myCard';
import MyCard1 from '../group/myCard1';

export default class App extends React.Component {
  render() {
    return (
      
        <MyCard1 />

      
    );
  }
}
