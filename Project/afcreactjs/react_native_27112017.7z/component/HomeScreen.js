import React from "react";
import { StatusBar,StyleSheet, View } from "react-native";
import {Container, Header, Title, Left, Icon, Right, Button, Body, Content,Text, Card, CardItem, Row } from "native-base";


import SearchBar from "./searchBar";

export default class HomeScreen extends React.Component {
  render() {
    return (
      <Container>
        <Header>
          <Left>
            <Button
              transparent
              onPress={() => this.props.navigation.navigate("DrawerOpen")}>
              <Icon name="menu" />
            </Button>
          </Left>
          <Body>
            <Title >HomeScreen</Title>
          </Body>
          <Right>
          </Right>
         
        </Header>
        
        <Content padder>
          <Card>
            <CardItem>
              <Body>
                <Text>Chat App to talk some awesome people!</Text>
              </Body>
            </CardItem>
          </Card>

          <Button full rounded dark
            style={{ marginTop: 10 }}
            onPress={() => this.props.navigation.navigate("Chat")}>
            <Text>Chat With People</Text>
          </Button>
          <Button full rounded primary
            style={{ marginTop: 10 }}
            onPress={() => this.props.navigation.navigate("Profile")}>
            <Text>Goto Profiles</Text>
          </Button>
        </Content>
      </Container>
    );
  }
}


// const styles = StyleSheet.create({
//     container: {
//       borderRadius: 4,
//       borderWidth: 0.5,
//       borderColor: '#d6d7da',
//     },
//     title: {
//       fontSize: 19,
//       fontWeight: 'bold',
//       flex:1,
//       flexDirection:'row',
//       alignItems:'center',
//       justifyContent:'center'
//     },

//     searchBar: {
//         fontSize: 19,
//         fontWeight: 'bold',
//         flex:1,
//         width:200,
//         flexDirection:'row',
//         alignItems:'flex-end',
//         justifyContent:'center'
//       },
//     activeTitle: {
//       color: 'red',
//     },
//   });
