import React, { Component } from "react";
import HomeScreen from "./HomeScreen.js";
import MainScreenNavigator from "./ChatScreen";
import Profile from "./Profile_index";
import SideBar from "./SideBar";
import {createAppContainer} from 'react-navigation';
import { createDrawerNavigator } from 'react-navigation-drawer';
const HomeScreenRouter = createDrawerNavigator(
  {
    Home: { screen: HomeScreen },
    Chat: { screen: MainScreenNavigator },
    Profile: { screen: Profile }
  },
  {
    // contentComponent: props => <SideBar {...props} />
  }
);
export default createAppContainer(HomeScreenRouter);