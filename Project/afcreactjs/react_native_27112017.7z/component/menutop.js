import React from 'react';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator } from 'react-navigation-drawer';

import Example from './Example'
import Screen1 from './Screen1'
import Screen2 from './Screen2'
import Screen3 from './Screen3'

//-----------------------------------------------
const MainTop = createMaterialTopTabNavigator({
  Feed: {
    screen: Example,
    navigationOptions: {
      tabBarLabel: 'Feed',
    },
  },
  Search: {
    screen: Example,
    navigationOptions: {
      tabBarLabel: 'Search',
    },
  },
  Discover: {
    screen: Example,
    navigationOptions: {
      tabBarLabel: 'Discover',
    },
  },
  Events: {
    screen: Example,
    navigationOptions: {
      tabBarLabel: 'events',
    },
  },
});



//------------------------------------------------------------

const FeedStack = createStackNavigator({
    Feed: {
      screen: Example,
      navigationOptions: {
        headerTitle: 'Feed',
      },
    },
    Details: {
      screen: Example,
      navigationOptions: {
        headerTitle: 'Details',
      },
    },
  });
  
  const SearchStack = createStackNavigator({
    Search: {
      screen: Example,
      navigationOptions: {
        headerTitle: 'Search',
      },
    },
    Details: {
      screen: Example,
      navigationOptions: {
        headerTitle: 'Details',
      },
    },
  });
  
  const DiscoverStack = createStackNavigator({
    Discover: {
      screen: Screen1,
      navigationOptions: {
        headerTitle: 'Discover',
      },
    },
    Details: {
      screen: Screen3,
      navigationOptions: {
        headerTitle: 'Details',
      },
    },
  });
//-------------------------------------------------------------
const MainTabs = createBottomTabNavigator({
    Feed: {
      screen: FeedStack,
      navigationOptions: {
        tabBarLabel: 'Feed',
      },
    },
    Search: {
      screen: SearchStack,
      navigationOptions: {
        tabBarLabel: 'Search',
      },
    },
    Discover: {
      screen: DiscoverStack,
      navigationOptions: {
        tabBarLabel: 'Discover',
      },
    },
  });
  
  //----------------------------------------------------------

//-------------------------------------

const Menu = createSwitchNavigator({
  
//   Top: {
//     screen: MainTop,
//   },
  
  Bottom: {
    screen: MainTabs,
  },
  
});

export default createAppContainer(Menu);