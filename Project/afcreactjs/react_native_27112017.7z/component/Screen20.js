'use strict';

//This is an example code for NavigationDrawer//
import React, { Component } from 'react';
//import react in our code.
import { StyleSheet, View, Text,ScrollView } from 'react-native';

import CardView from 'react-native-cardview';

import { Card } from 'react-native-elements';


import MyCard from '../group/myCard';
import MyCard1 from '../group/myCard1';
import MySlider from '../group/mySlider';
import MyOverlay from '../group/myOverlay';

import Floating_Action_Button from '../group/floating_Action_Button';



export default class App extends React.Component {
  render() {
    return (
      
         <Floating_Action_Button />

      
    );
  }
}
