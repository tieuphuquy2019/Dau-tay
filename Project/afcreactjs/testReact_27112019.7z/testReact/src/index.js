import React from 'react';
import ReactDOM from 'react-dom';
import SocketCl from './socketCL/socketCL';
import App from './App';
//import Clock from './clock';
import * as serviceWorker from './serviceWorker';


ReactDOM.render(<App />,document.getElementById('ProductList'));
ReactDOM.render(<SocketCl />,document.getElementById('socketCL'));
//ReactDOM.render(<Clock />,document.getElementById('socketCL'));

serviceWorker.unregister();

