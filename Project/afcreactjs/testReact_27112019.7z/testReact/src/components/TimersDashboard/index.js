import React from 'react';
import ReactDOM from 'react-dom';
import TimersDashboard from './TimersDashboard';

export default  TimersDashboard;
