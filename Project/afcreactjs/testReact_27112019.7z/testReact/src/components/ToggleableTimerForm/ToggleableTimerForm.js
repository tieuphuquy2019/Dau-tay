import React from 'react';
//import 'bootstrap/dist/css/bootstrap'; 
//import { Button } from 'reactstrap';
import ReactDOM from 'react-dom';
//import '/bootstrap/dist/css/bootstrap.css';
//import 'bootstrap/dist/css/bootstrap.min.css';


class ToggleableTimerForm extends React.Component {
    state = {
    isOpen: false,
    };
    handleFormOpen = () => {
        this.setState({ isOpen: true });
    };
    render() {
        if (this.state.isOpen) {
            return (
            <TimerForm />
            );
        } else {
            return (
            <div className='ui basic content center aligned segment'>
            <button
            className='ui basic button icon'
            onClick={this.handleFormOpen}
            >
            <i className='plus icon' />
            </button>
            </div>
            );
        }
    }
}