import React from 'react';
//import 'bootstrap/dist/css/bootstrap'; 
//import { Button } from 'reactstrap';
import ReactDOM from 'react-dom';
//import '/bootstrap/dist/css/bootstrap.css';
//import 'bootstrap/dist/css/bootstrap.min.css';
import Product from '../Product';
import Seedproducts from '../Product/model/Seedproducts';
class ProductList extends React.Component {

        constructor(props, context) {
                super(props);
                this.handleProductUpVote = this.handleProductUpVote.bind(this);
                this.props = {

                }
                this.state = {
                    Product:[],
                }

            }
            componentDidMount(){
                this.setState(
                    {
                        Product:Seedproducts
                    }

                );
                }

                handleProductUpVote = (productId) => {
                    const nextProducts = this.state.products.map((product) => {
                    if (product.id === productId) {
                    return Object.assign({}, product, {
                    votes: product.votes + 1,
                    });
                    } else {
                    return product;
                    }
                    });
                    this.setState({
                    products: nextProducts,
                    });
                    }              

        render() {
               const products = this.state.Product;
                return ( < div className = 'ui unstackable items' >{products}</div>);
            }
}
export default ProductList;
