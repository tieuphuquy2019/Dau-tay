const products = [
    {
    id: 1,
    title: 'Yellow Pail1',
    description: 'On-demand sand castle construction expertise.',
    url: '#',
    votes: 'generateVoteCount()1',
    submitterAvatarUrl: 'react/assets/images/daniel.jpg',
    productImageUrl: 'react/assets/images/image-aqua.png',
    },

    {
        id: 2,
        title: 'Yellow Pail2',
        description: 'On-demand sand castle construction expertise.',
        url: '#',
        votes: 'generateVoteCount()2',
        submitterAvatarUrl: 'react/assets/images/daniel.jpg',
        productImageUrl: 'react/assets/images/image-aqua.png',
    },

    {
            id: 3,
            title: 'Yellow Pail3',
            description: 'On-demand sand castle construction expertise.',
            url: '#',
            votes: 'generateVoteCount()3',
            submitterAvatarUrl: 'react/assets/images/daniel.jpg',
            productImageUrl: 'react/assets/images/image-aqua.png',
    }

]

export default products;

