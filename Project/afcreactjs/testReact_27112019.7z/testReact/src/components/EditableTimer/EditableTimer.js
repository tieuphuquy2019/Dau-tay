import React from 'react';
//import 'bootstrap/dist/css/bootstrap'; 
//import { Button } from 'reactstrap';
import ReactDOM from 'react-dom';
//import '/bootstrap/dist/css/bootstrap.css';
//import 'bootstrap/dist/css/bootstrap.min.css';


class EditableTimer extends React.Component {
    state = {
                editFormOpen: false,
    };
    render() {
        if (this.state.editFormOpen) {
            return (
            <TimerForm
            id={this.props.id}
            title={this.props.title}
            project={this.props.project}
            />
        );
        } else {
            return (
            <Timer
            id={this.props.id}
            title={this.props.title}
            project={this.props.project}
            elapsed={this.props.elapsed}
            runningSince={this.props.runningSince}
            />
            );
        }
    }
}