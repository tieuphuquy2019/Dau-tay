import React from 'react';
import ReactDOM from 'react-dom';
import EditableTimer from './EditableTimer';

export default  EditableTimer;
