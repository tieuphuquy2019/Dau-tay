import React from 'react';
import ReactDOM from 'react-dom';


const Route = ({ path, Component }) => {
  // const pathname = window.location.pathname;
   //if (path ==  pathname) {
    return (
          React.createElement(Component)
    )
//   }
 
};

export default Route;